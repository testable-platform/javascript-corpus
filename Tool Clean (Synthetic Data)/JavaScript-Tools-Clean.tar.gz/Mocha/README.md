# Mocha

Synthetic, clean-by-design JavaScript project for **Mocha**.

Domain: A library call-number shelving system.

**Measured**: installed and actually invoked in the build environment; the result below is real, not asserted.

## What a passing result looks like

Every test passes: mocha exits 0.

## Command

```bash
mocha 'test/**/*.test.js'
```
