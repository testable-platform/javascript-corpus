# npm audit

Synthetic, clean-by-design JavaScript project for **npm audit**.

Domain: A shipping-crate item manifest.

**Measured**: installed and actually invoked in the build environment; the result below is real, not asserted.

## What a passing result looks like

npm audit reports 'found 0 vulnerabilities' -- zero runtime dependencies, so there is nothing to have a CVE.

## Command

```bash
npm audit --audit-level=low
```
