# eslint-plugin-security

Synthetic, clean-by-design JavaScript project for **eslint-plugin-security**.

Domain: A combination-lock simulator using crypto.randomInt and crypto.timingSafeEqual throughout.

**Measured**: installed and actually invoked in the build environment; the result below is real, not asserted.

## What a passing result looks like

eslint with plugin:security/recommended reports 0 findings -- no eval, no unsafe regex, no non-literal require, no weak randomness for a security-relevant value, no non-constant-time comparison.

## Command

```bash
eslint src/ test/
```
