# npm ls

Synthetic, clean-by-design JavaScript project for **npm ls**.

Domain: A courier's parcel-satchel route tracker.

**Measured**: installed and actually invoked in the build environment; the result below is real, not asserted.

## What a passing result looks like

npm ls --all exits 0 with no missing, invalid, or extraneous entries.

## Command

```bash
npm ls --all
```
