# knip

Synthetic, clean-by-design JavaScript project for **knip**.

Domain: A small seasonal flower catalog.

**Measured**: installed and actually invoked in the build environment; the result below is real, not asserted.

## What a passing result looks like

knip reports zero unused files, exports, or dependencies, and zero configuration hints.

## Command

```bash
knip
```

## Notes

First pass was clean of real findings but printed a 'redundant entry pattern' configuration hint (index.js already matches knip's default entry glob, so declaring it again in knip.json was noise); removed the redundant declaration so the run is completely silent.
