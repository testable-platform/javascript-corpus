# ESLint

Synthetic, clean-by-design JavaScript project for **ESLint**.

Domain: A cafe order queue with running-total pricing.

**Measured**: installed and actually invoked in the build environment; the result below is real, not asserted.

## What a passing result looks like

eslint reports 0 errors and 0 warnings against a flat config (eslint.config.js) covering src/ and test/.

## Command

```bash
eslint src/ test/
```
