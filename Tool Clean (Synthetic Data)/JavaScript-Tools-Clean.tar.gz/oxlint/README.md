# oxlint

Synthetic, clean-by-design JavaScript project for **oxlint**.

Domain: A tide-station reading log.

**Measured**: installed and actually invoked in the build environment; the result below is real, not asserted.

## What a passing result looks like

oxlint reports 0 errors and 0 warnings.

## Command

```bash
oxlint src/ test/
```
