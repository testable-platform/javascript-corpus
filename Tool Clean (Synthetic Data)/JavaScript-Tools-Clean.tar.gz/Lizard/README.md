# Lizard

Synthetic, clean-by-design JavaScript project for **Lizard**.

Domain: A windmill power-output estimator.

**Measured**: installed and actually invoked in the build environment; the result below is real, not asserted.

## What a passing result looks like

lizard -C 10 -L 60 -a 5 -w prints no warnings -- every function's CCN, length, and parameter count stays under threshold.

## Command

```bash
lizard src/ -C 10 -L 60 -a 5 -w
```

## Notes

External tool (pip install lizard), same as the Python sibling corpus; lizard parses JavaScript natively.
