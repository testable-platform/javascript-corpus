# gutcheck

Synthetic, clean-by-design JavaScript project for **gutcheck**.

Domain: A tiered utility-meter billing calculator.

**Measured**: installed and actually invoked in the build environment; the result below is real, not asserted.

## What a passing result looks like

gutcheck . (mocha auto-detected) reports every probeable function PROVEN, 0 HOLLOW, 0 untested.

## Command

```bash
gutcheck .
```

## Notes

First pass caught a real arithmetic mistake in this folder's own test (an expected value computed by hand was off by 100) -- gutcheck reported the test failing before any mutation even ran, exactly the class of bug it exists to surface. Fixed in the test, not worked around.
