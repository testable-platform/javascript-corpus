# trivy

Synthetic, clean-by-design JavaScript project for **trivy**.

Domain: A cargo-yard loading-dock drop-off scheduler.

**Not installed here**: see Notes for why, and what was checked instead.

## What a passing result looks like

0 vulnerabilities, 0 secrets -- zero runtime dependencies and no credential-shaped strings anywhere in source.

## Command

```bash
trivy fs --scanners vuln,secret --exit-code 1 .
```

## Notes

The trivy binary is a GitHub release asset; this sandbox's egress allowlist returns 403 for it (same constraint as the Python sibling corpus).
