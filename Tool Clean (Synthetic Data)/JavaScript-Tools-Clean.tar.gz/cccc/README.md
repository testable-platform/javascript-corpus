# cccc

CCCC (C and C++ Code Counter) analyses C, C++, and Java source, not
JavaScript. The Testable platform's own build-contract notes flag this
folder's registration as a category error: it was pulled in as a
"Cognitive Complexity" alternative for the JavaScript roster, but CCCC
does not measure cognitive complexity and cannot parse JavaScript at
all (see `claude/javascript-repos-build-contract.md`'s "Roster repair"
section). Rather than force-feed it JavaScript it cannot read, this
folder gives CCCC genuine, small C source of its own -- the one thing
it can actually analyse cleanly.
