# eslint-plugin-sonarjs

Synthetic, clean-by-design JavaScript project for **eslint-plugin-sonarjs**.

Domain: A train ticket queue with per-class fares.

**Measured**: installed and actually invoked in the build environment; the result below is real, not asserted.

## What a passing result looks like

eslint with plugin:sonarjs/recommended reports 0 findings -- no duplicated branches, no collapsible conditionals, low cognitive complexity throughout.

## Command

```bash
eslint src/ test/
```

## Notes

Needs its own local `npm install`, not a shared node_modules: eslint-plugin-sonarjs pins its own typescript range internally (via ts-api-utils), and an unrelated newer typescript hoisted at a shared root will get deduped into its dependency tree and crash (confirmed: TypeScript 7.0.2 breaks ts-api-utils@2.5.0, which expects TypeScript 5.x/6.x's internal API). A folder-local install resolves this correctly.
