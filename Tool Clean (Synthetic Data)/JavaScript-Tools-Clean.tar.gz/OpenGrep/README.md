# OpenGrep

Synthetic, clean-by-design JavaScript project for **OpenGrep**.

Domain: A gate-access badge controller with a cryptographically random visitor-code generator.

**Not installed here**: see Notes for why, and what was checked instead.

## What a passing result looks like

0 findings against the folder's own committed semgrep-rules.yml (no eval, no shell-command concatenation, no Math.random() for a security-sensitive value).

## Command

```bash
opengrep --config=semgrep-rules.yml --error src/
```

## Notes

The opengrep binary is a GitHub release asset; this sandbox's egress allowlist returns 403 for it (same constraint as the Python sibling corpus). As a same-engine stand-in, `semgrep --config=semgrep-rules.yml` (installed from PyPI) was run for real against this exact ruleset and source, and reported 0 findings.
