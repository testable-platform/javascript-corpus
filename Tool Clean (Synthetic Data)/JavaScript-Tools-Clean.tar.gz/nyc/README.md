# nyc

Synthetic, clean-by-design JavaScript project for **nyc**.

Domain: A payroll calculator with an overtime multiplier.

**Measured**: installed and actually invoked in the build environment; the result below is real, not asserted.

## What a passing result looks like

nyc --check-coverage reports 100% statements, branches, functions, and lines.

## Command

```bash
nyc --check-coverage --lines 100 --branches 100 --functions 100 --statements 100 mocha 'test/**/*.test.js'
```
