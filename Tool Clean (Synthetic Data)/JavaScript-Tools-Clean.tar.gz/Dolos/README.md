# Dolos

Synthetic, clean-by-design JavaScript project for **Dolos**.

Domain: An aquarium kelp-growth and water-chemistry tracker split across three files with deliberately distinct vocabulary and logic.

**Measured**: installed and actually invoked in the build environment; the result below is real, not asserted.

## What a passing result looks like

Every pairwise similarity score Dolos reports across the three source files stays low (all under 0.2 here) -- no real code-clone signal.

## Command

```bash
dolos run src/*.js -l javascript
```

## Notes

Needed a native rebuild (node-gyp) at install time; the default install failed because node-gyp tries to fetch Node headers from nodejs.org, which this sandbox blocks. Fixed with `npm install --nodedir=<local node include dir>`, pointing node-gyp at headers already on disk instead of downloading them.
