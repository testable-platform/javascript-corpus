# jscpd

Synthetic, clean-by-design JavaScript project for **jscpd**.

Domain: A spice-inventory crate and a shelf-placement planner, two structurally distinct files.

**Measured**: installed and actually invoked in the build environment; the result below is real, not asserted.

## What a passing result looks like

jscpd reports 0 clones at --min-lines 5 --min-tokens 30 --threshold 0.

## Command

```bash
jscpd src/ --min-lines 5 --min-tokens 30 --threshold 0 --reporters console
```
