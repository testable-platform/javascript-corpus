# monocart-coverage-reports

Synthetic, clean-by-design JavaScript project for **monocart-coverage-reports**.

Domain: A warehouse shelf item-count tracker.

**Measured**: installed and actually invoked in the build environment; the result below is real, not asserted.

## What a passing result looks like

The json-summary report's entry for src/shelfcount.js shows 100% lines, statements, functions, and branches.

## Command

```bash
mcr node node_modules/.bin/mocha 'test/**/*.test.js' -r v8,json-summary -o coverage-report
```

## Notes

monocart has no built-in fail-under threshold (its CLI never calls process.exit(1) on low coverage by design), so this folder's own check reads the generated coverage-summary.json and asserts 100% on its own source file directly, rather than trusting the command's exit code alone.
